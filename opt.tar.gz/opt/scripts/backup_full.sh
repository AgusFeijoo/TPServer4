#! /bin/bash

function ayuda {
	echo "Uso: $0 [-h] [origen destino]"
	echo "  -h               Muestra ayuda"
	echo " "
	echo "Descripción: Vamos a hacer backups de /www_dir y /var/log"
	echo "  $0  /var/log  /backup_dir"
	echo "  $0  /www_dir  /backup_dir"
	exit 0
}

#validación de argumentos y creamos la opcion de mostrar ayuda
if [[ "$1" == "-h" || "$1" == "--help" ]]; then
	ayuda
fi

if [[ $# -ne 2 ]]; then
	echo "Error: Se requieren 2 argumentos (origen y destino). Usa -h para ayuda."
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)

#validamos que no se ingresen otros directorios que no sean los solicitados
if [[ "$ORIGEN" != "/www_dir" && "$ORIGEN" != "/var/log" ]]; then
	echo "Error: Solo queremos hacer un backup de los directorios solicitados"
	exit 1
fi

#validamos que los directorios de origen y destino existan
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio '$ORIGEN' no existe."
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: El directorio '$DESTINO' no existe."
	exit 1
fi

#nombre backup formato ansi
NOMBRE_BKP="$(basename "$ORIGEN")_bkp_$FECHA.tar.gz"

# backup
if [[ "$ORIGEN" == "/var/log" ]]; then
	tar -czf "$DESTINO/$NOMBRE_BKP" -C /var/log .
else
	tar -czf "$DESTINO/$NOMBRE_BKP" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")" 2>/dev/null

fi

#verificamos si funciono el backup
if [[ $? -eq 0 ]]; then
	echo "Backup exitoso: $DESTINO/$NOMBRE_BKP"
	exit 0
else
	echo "¡Error al crear el backup!"
	exit 1
fi

